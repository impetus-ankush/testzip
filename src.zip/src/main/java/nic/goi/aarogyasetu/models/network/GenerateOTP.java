package nic.goi.aarogyasetu.models.network;

public class GenerateOTP {
    private String primaryId;

    public GenerateOTP(String primaryId) {
        this.primaryId = primaryId;
    }
}
