package nic.goi.aarogyasetu.models


/**
 * @author Niharika.Arora
 */
class EncryptedInfo {
    var data: String? = null
    var iv: ByteArray? = null
}
