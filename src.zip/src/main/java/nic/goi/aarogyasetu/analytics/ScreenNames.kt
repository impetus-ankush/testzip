package nic.goi.aarogyasetu.analytics

object ScreenNames {

    const val SCREEN_SPLASH = "splashScreen"
    const val SCREEN_LOGIN = "loginScreen"
    const val SCREEN_PERMISSION = "permissionScreen"
    const val SCREEN_DASHBOARD = "webView"
}